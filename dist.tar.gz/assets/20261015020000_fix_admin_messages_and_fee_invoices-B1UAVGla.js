const e=`-- SQL Migration to fix missing columns on admin_messages, fee_invoices, and student_certificates tables\r
\r
-- 1. Alter admin_messages Table\r
ALTER TABLE public.admin_messages ADD COLUMN IF NOT EXISTS content text;\r
ALTER TABLE public.admin_messages ADD COLUMN IF NOT EXISTS priority text NOT NULL DEFAULT 'normal';\r
ALTER TABLE public.admin_messages ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'sent';\r
ALTER TABLE public.admin_messages ADD COLUMN IF NOT EXISTS attachment_urls text[] DEFAULT '{}'::text[];\r
ALTER TABLE public.admin_messages ADD COLUMN IF NOT EXISTS created_by uuid;\r
ALTER TABLE public.admin_messages ADD COLUMN IF NOT EXISTS reply_to_id uuid REFERENCES public.admin_messages(id) ON DELETE SET NULL;\r
ALTER TABLE public.admin_messages ADD COLUMN IF NOT EXISTS campus_id uuid;\r
\r
-- 2. Drop legacy body/content trigger on admin_messages\r
DROP TRIGGER IF EXISTS trg_sync_admin_messages_body_content ON public.admin_messages;\r
DROP FUNCTION IF EXISTS public.sync_admin_messages_body_content();\r
\r
\r
-- 3. Alter fee_invoices Table\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS amount numeric(12,2) NOT NULL DEFAULT 0;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS discount_amount numeric(12,2) NOT NULL DEFAULT 0;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS late_fee numeric(12,2) NOT NULL DEFAULT 0;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS merit_discount_amount numeric(12,2) NOT NULL DEFAULT 0;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS merit_discount_reason text;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS notes text;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS paid_amount numeric(12,2) NOT NULL DEFAULT 0;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS period_end date;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS period_label text;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS period_start date;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS sibling_discount_amount numeric(12,2) NOT NULL DEFAULT 0;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS subtotal numeric(12,2) NOT NULL DEFAULT 0;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS total_amount numeric(12,2) NOT NULL DEFAULT 0;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS fee_plan_id uuid REFERENCES public.fee_plans(id) ON DELETE SET NULL;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS campus_id uuid;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS updated_at timestamp with time zone DEFAULT now();\r
\r
-- 4. Trigger to Sync fee_invoices amount and total_amount\r
CREATE OR REPLACE FUNCTION public.sync_fee_invoices_amounts()\r
RETURNS TRIGGER AS $$\r
BEGIN\r
  IF NEW.total_amount IS NOT NULL AND NEW.total_amount != 0 AND (NEW.amount IS NULL OR NEW.amount = 0) THEN\r
    NEW.amount := NEW.total_amount;\r
  ELSIF NEW.amount IS NOT NULL AND NEW.amount != 0 AND (NEW.total_amount IS NULL OR NEW.total_amount = 0) THEN\r
    NEW.total_amount := NEW.amount;\r
  END IF;\r
  RETURN NEW;\r
END;\r
$$ LANGUAGE plpgsql;\r
\r
DROP TRIGGER IF EXISTS trg_sync_fee_invoices_amounts ON public.fee_invoices;\r
CREATE TRIGGER trg_sync_fee_invoices_amounts\r
BEFORE INSERT OR UPDATE ON public.fee_invoices\r
FOR EACH ROW\r
EXECUTE FUNCTION public.sync_fee_invoices_amounts();\r
\r
\r
-- 5. Alter student_certificates Table\r
ALTER TABLE public.student_certificates ADD COLUMN IF NOT EXISTS issued_at date;\r
\r
-- Populate issued_at from issued_date for existing rows\r
UPDATE public.student_certificates \r
SET issued_at = issued_date \r
WHERE issued_at IS NULL AND issued_date IS NOT NULL;\r
\r
\r
-- 6. Reload Schema Cache\r
NOTIFY pgrst, 'reload schema';\r
`;export{e as default};
