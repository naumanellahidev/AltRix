const e=`
ALTER VIEW public.complaint_feedbacks_principal_view SET (security_invoker = true);
`;export{e as default};
