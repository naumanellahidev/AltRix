import{j as t,ad as a}from"./index-pWOk_0yK.js";function m({className:e,...s}){return t.jsx("div",{className:a("animate-pulse rounded-md bg-muted",e),...s})}export{m as S};
