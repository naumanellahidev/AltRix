const t="CREATE UNIQUE INDEX IF NOT EXISTS ai_student_profiles_school_student_uq ON public.ai_student_profiles (school_id, student_id);";export{t as default};
