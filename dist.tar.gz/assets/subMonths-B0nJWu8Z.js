import{a as t}from"./addMonths-DTE3kuYO.js";function r(o,s){return t(o,-s)}export{r as s};
