import{j as t,ad as a}from"./index-DZWmjE4u.js";function m({className:e,...s}){return t.jsx("div",{className:a("animate-pulse rounded-md bg-muted",e),...s})}export{m as S};
