const n=`-- Add columns to public.complaints\r
ALTER TABLE public.complaints \r
  ADD COLUMN IF NOT EXISTS priority TEXT CHECK (priority IN ('low','medium','high')) DEFAULT 'medium',\r
  ADD COLUMN IF NOT EXISTS anonymous BOOLEAN DEFAULT true,\r
  ADD COLUMN IF NOT EXISTS rating INTEGER CHECK (rating BETWEEN 1 AND 5),\r
  ADD COLUMN IF NOT EXISTS rating_comment TEXT,\r
  ADD COLUMN IF NOT EXISTS attachments JSONB DEFAULT '[]'::jsonb;\r
\r
-- Re-create complaints_principal_view to support the new columns and optional anonymity\r
CREATE OR REPLACE VIEW public.complaints_principal_view\r
WITH (security_invoker=on) AS\r
  SELECT\r
    id,\r
    school_id,\r
    flow,\r
    CASE WHEN (flow = 'student_to_principal' AND anonymous = true) THEN NULL ELSE sender_user_id END AS sender_user_id,\r
    student_id,\r
    category,\r
    subject,\r
    content,\r
    status,\r
    priority,\r
    anonymous,\r
    rating,\r
    rating_comment,\r
    attachments,\r
    resolution_note,\r
    resolved_by,\r
    resolved_at,\r
    created_at,\r
    updated_at\r
  FROM public.complaints;\r
\r
-- Re-create complaint_feedbacks_principal_view to support optional anonymity\r
CREATE OR REPLACE VIEW public.complaint_feedbacks_principal_view\r
WITH (security_invoker=on) AS\r
SELECT\r
  f.id,\r
  f.complaint_id,\r
  f.school_id,\r
  CASE WHEN c.flow = 'student_to_principal' AND c.anonymous = true AND f.author_role = 'sender'\r
       THEN NULL ELSE f.author_user_id END AS author_user_id,\r
  f.author_role,\r
  f.content,\r
  f.created_at,\r
  f.updated_at\r
FROM public.complaint_feedbacks f\r
JOIN public.complaints c ON c.id = f.complaint_id;\r
\r
-- Add complaints and complaint_feedbacks to the supabase_realtime publication\r
DO $$\r
BEGIN\r
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') THEN\r
    -- Check if complaints is already in publication, if not add it\r
    IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'complaints') THEN\r
      ALTER PUBLICATION supabase_realtime ADD TABLE public.complaints;\r
    END IF;\r
    -- Check if complaint_feedbacks is already in publication, if not add it\r
    IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'complaint_feedbacks') THEN\r
      ALTER PUBLICATION supabase_realtime ADD TABLE public.complaint_feedbacks;\r
    END IF;\r
  END IF;\r
END $$;\r
`;export{n as default};
