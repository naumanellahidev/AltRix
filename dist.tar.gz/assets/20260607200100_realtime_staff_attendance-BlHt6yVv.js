const a=`-- Enable real-time replication for hr_staff_attendance table\r
DO $$\r
BEGIN\r
  IF EXISTS (\r
    SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime'\r
  ) THEN\r
    IF NOT EXISTS (\r
      SELECT 1 FROM pg_publication_tables\r
      WHERE pubname = 'supabase_realtime'\r
        AND schemaname = 'public'\r
        AND tablename = 'hr_staff_attendance'\r
    ) THEN\r
      ALTER PUBLICATION supabase_realtime ADD TABLE public.hr_staff_attendance;\r
    END IF;\r
  END IF;\r
EXCEPTION\r
  WHEN OTHERS THEN\r
    NULL;\r
END\r
$$;\r
`;export{a as default};
