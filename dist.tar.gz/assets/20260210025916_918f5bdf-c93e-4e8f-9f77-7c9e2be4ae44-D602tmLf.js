const e="ALTER TABLE public.school_memberships ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'active';";export{e as default};
