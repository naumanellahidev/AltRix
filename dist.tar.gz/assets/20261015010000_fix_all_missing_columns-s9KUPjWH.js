const e=`-- SQL Migration to fix all missing columns and tables across all AltRix ERP modules\r
\r
-- 1. Create cleared_conversations table if not exists\r
CREATE TABLE IF NOT EXISTS public.cleared_conversations (\r
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),\r
  school_id uuid NOT NULL,\r
  user_id uuid NOT NULL,\r
  partner_user_id uuid NOT NULL,\r
  cleared_at timestamp with time zone NOT NULL DEFAULT now(),\r
  UNIQUE(school_id, user_id, partner_user_id)\r
);\r
\r
-- 2. Create fee_reminders table if not exists\r
CREATE TABLE IF NOT EXISTS public.fee_reminders (\r
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),\r
  school_id uuid NOT NULL,\r
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,\r
  invoice_id uuid NOT NULL REFERENCES public.finance_invoices(id) ON DELETE CASCADE,\r
  reminder_type text NOT NULL,\r
  scheduled_date date NOT NULL,\r
  status text NOT NULL DEFAULT 'pending', -- 'pending', 'sent', 'failed'\r
  message text,\r
  sent_at timestamp with time zone,\r
  created_at timestamp with time zone DEFAULT now()\r
);\r
\r
-- 3. Create ai_timetable_suggestions table if not exists\r
CREATE TABLE IF NOT EXISTS public.ai_timetable_suggestions (\r
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),\r
  school_id uuid NOT NULL,\r
  class_section_id uuid NOT NULL,\r
  suggestion_data jsonb NOT NULL,\r
  optimization_score numeric(5,2),\r
  conflicts_found jsonb,\r
  status text NOT NULL DEFAULT 'draft',\r
  version_number integer NOT NULL DEFAULT 1,\r
  created_at timestamp with time zone DEFAULT now(),\r
  approved_at timestamp with time zone,\r
  approved_by uuid\r
);\r
\r
-- 4. Create parent_notification_preferences table if not exists\r
CREATE TABLE IF NOT EXISTS public.parent_notification_preferences (\r
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),\r
  school_id uuid NOT NULL,\r
  user_id uuid NOT NULL,\r
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,\r
  notify_absent boolean NOT NULL DEFAULT true,\r
  notify_late boolean NOT NULL DEFAULT true,\r
  notify_grades boolean NOT NULL DEFAULT true,\r
  notify_homework boolean NOT NULL DEFAULT true,\r
  low_grade_threshold numeric(5,2) DEFAULT 50.00,\r
  created_at timestamp with time zone DEFAULT now(),\r
  updated_at timestamp with time zone DEFAULT now(),\r
  UNIQUE(user_id, student_id)\r
);\r
\r
-- 5. Create timetable_period_logs table if not exists\r
CREATE TABLE IF NOT EXISTS public.timetable_period_logs (\r
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),\r
  school_id uuid NOT NULL,\r
  timetable_entry_id uuid NOT NULL,\r
  teacher_user_id uuid NOT NULL,\r
  topic_covered text,\r
  notes text,\r
  logged_at timestamp with time zone DEFAULT now(),\r
  updated_at timestamp with time zone DEFAULT now()\r
);\r
\r
-- 6. Create audit_logs table if not exists\r
CREATE TABLE IF NOT EXISTS public.audit_logs (\r
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),\r
  school_id uuid NOT NULL,\r
  user_id uuid,\r
  actor_user_id uuid,\r
  action text NOT NULL,\r
  resource_type text NOT NULL,\r
  entity_type text,\r
  resource_id text,\r
  entity_id text,\r
  old_values jsonb,\r
  new_values jsonb,\r
  metadata jsonb,\r
  ip_address text,\r
  user_agent text,\r
  created_at timestamp with time zone DEFAULT now()\r
);\r
\r
-- 7. Create school_bootstrap table if not exists\r
CREATE TABLE IF NOT EXISTS public.school_bootstrap (\r
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),\r
  school_id uuid UNIQUE NOT NULL,\r
  locked boolean DEFAULT false,\r
  bootstrapped_at timestamp with time zone,\r
  created_at timestamp with time zone DEFAULT now()\r
);\r
\r
-- 8. Alter Students table columns\r
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS end_date date;\r
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS class_section_id uuid REFERENCES public.class_sections(id) ON DELETE SET NULL;\r
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS created_by uuid;\r
\r
-- 9. Alter User Roles table columns\r
ALTER TABLE public.user_roles ADD COLUMN IF NOT EXISTS end_date date;\r
\r
-- 10. Alter Complaints table columns\r
ALTER TABLE public.complaints ADD COLUMN IF NOT EXISTS priority text NOT NULL DEFAULT 'medium';\r
ALTER TABLE public.complaints ADD COLUMN IF NOT EXISTS anonymous boolean NOT NULL DEFAULT false;\r
ALTER TABLE public.complaints ADD COLUMN IF NOT EXISTS rating integer;\r
ALTER TABLE public.complaints ADD COLUMN IF NOT EXISTS rating_comment text;\r
ALTER TABLE public.complaints ADD COLUMN IF NOT EXISTS attachments jsonb;\r
\r
-- 11. Alter Student Marks table columns\r
ALTER TABLE public.student_marks ADD COLUMN IF NOT EXISTS remarks text;\r
ALTER TABLE public.student_marks ADD COLUMN IF NOT EXISTS is_published boolean NOT NULL DEFAULT false;\r
ALTER TABLE public.student_marks ADD COLUMN IF NOT EXISTS published_at timestamp with time zone;\r
ALTER TABLE public.student_marks ADD COLUMN IF NOT EXISTS assessment_date date;\r
ALTER TABLE public.student_marks ADD COLUMN IF NOT EXISTS max_marks numeric(10,2);\r
ALTER TABLE public.student_marks ADD COLUMN IF NOT EXISTS sender_user_id uuid;\r
\r
-- 12. Alter Finance Invoices table columns\r
ALTER TABLE public.finance_invoices ADD COLUMN IF NOT EXISTS late_fee_total numeric(12,2) NOT NULL DEFAULT 0;\r
ALTER TABLE public.finance_invoices ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true;\r
ALTER TABLE public.finance_invoices ADD COLUMN IF NOT EXISTS instructions text;\r
\r
-- 13. Alter Timetable Entries and Teacher Assignments columns\r
ALTER TABLE public.timetable_entries ADD COLUMN IF NOT EXISTS teacher_id uuid;\r
ALTER TABLE public.teacher_subject_assignments ADD COLUMN IF NOT EXISTS teacher_id uuid;\r
\r
-- 14. Alter HR Staff Attendance columns\r
ALTER TABLE public.hr_staff_attendance ADD COLUMN IF NOT EXISTS reviewed_by uuid;\r
ALTER TABLE public.hr_staff_attendance ADD COLUMN IF NOT EXISTS reviewed_at timestamp with time zone;\r
\r
-- 15. Alter HR Leave Requests columns\r
ALTER TABLE public.hr_leave_requests ADD COLUMN IF NOT EXISTS is_paid boolean NOT NULL DEFAULT true;\r
ALTER TABLE public.hr_leave_requests ADD COLUMN IF NOT EXISTS max_days integer;\r
\r
-- 16. Alter HR Payslips columns\r
ALTER TABLE public.hr_payslips ADD COLUMN IF NOT EXISTS total_gross numeric(12,2) NOT NULL DEFAULT 0;\r
ALTER TABLE public.hr_payslips ADD COLUMN IF NOT EXISTS generated_at timestamp with time zone DEFAULT now();\r
ALTER TABLE public.hr_payslips ADD COLUMN IF NOT EXISTS total_deductions numeric(12,2) NOT NULL DEFAULT 0;\r
ALTER TABLE public.hr_payslips ADD COLUMN IF NOT EXISTS total_net numeric(12,2) NOT NULL DEFAULT 0;\r
\r
-- 17. Alter Fee Invoices columns\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS waiver numeric(12,2) NOT NULL DEFAULT 0;\r
ALTER TABLE public.fee_invoices ADD COLUMN IF NOT EXISTS "Waiver" numeric(12,2) NOT NULL DEFAULT 0;\r
\r
-- 18. Alter Fee Voucher Batches columns\r
ALTER TABLE public.fee_voucher_batches ADD COLUMN IF NOT EXISTS discount_pct numeric(5,2);\r
ALTER TABLE public.fee_voucher_batches ADD COLUMN IF NOT EXISTS "sectionId" uuid;\r
ALTER TABLE public.fee_voucher_batches ADD COLUMN IF NOT EXISTS min_grade text;\r
\r
-- 19. Alter School Branding columns\r
ALTER TABLE public.school_branding ADD COLUMN IF NOT EXISTS latitude numeric(10,8);\r
ALTER TABLE public.school_branding ADD COLUMN IF NOT EXISTS longitude numeric(11,8);\r
ALTER TABLE public.school_branding ADD COLUMN IF NOT EXISTS altitude numeric(10,2);\r
\r
-- 20. Align Scheduled Messages Table (Rename and Add columns)\r
DO $$\r
BEGIN\r
  IF EXISTS (\r
    SELECT 1 \r
    FROM information_schema.columns \r
    WHERE table_schema = 'public' \r
      AND table_name = 'scheduled_messages' \r
      AND column_name = 'scheduled_for'\r
  ) AND NOT EXISTS (\r
    SELECT 1 \r
    FROM information_schema.columns \r
    WHERE table_schema = 'public' \r
      AND table_name = 'scheduled_messages' \r
      AND column_name = 'scheduled_at'\r
  ) THEN\r
    ALTER TABLE public.scheduled_messages RENAME COLUMN scheduled_for TO scheduled_at;\r
  END IF;\r
END $$;\r
\r
ALTER TABLE public.scheduled_messages ADD COLUMN IF NOT EXISTS message_type text NOT NULL DEFAULT 'admin';\r
ALTER TABLE public.scheduled_messages ADD COLUMN IF NOT EXISTS attachment_urls text[] DEFAULT '{}'::text[];\r
ALTER TABLE public.scheduled_messages ADD COLUMN IF NOT EXISTS updated_at timestamp with time zone DEFAULT now();\r
ALTER TABLE public.scheduled_messages ADD COLUMN IF NOT EXISTS error_message text;\r
\r
-- 21. Create Triggers for Timetable teacher_id <-> teacher_user_id sync\r
CREATE OR REPLACE FUNCTION public.sync_timetable_entries_teacher()\r
RETURNS TRIGGER AS $$\r
BEGIN\r
  IF TG_OP = 'INSERT' THEN\r
    IF NEW.teacher_id IS NULL AND NEW.teacher_user_id IS NOT NULL THEN\r
      NEW.teacher_id := NEW.teacher_user_id;\r
    ELSIF NEW.teacher_user_id IS NULL AND NEW.teacher_id IS NOT NULL THEN\r
      NEW.teacher_user_id := NEW.teacher_id;\r
    END IF;\r
  ELSIF TG_OP = 'UPDATE' THEN\r
    IF NEW.teacher_id IS DISTINCT FROM OLD.teacher_id THEN\r
      NEW.teacher_user_id := NEW.teacher_id;\r
    ELSIF NEW.teacher_user_id IS DISTINCT FROM OLD.teacher_user_id THEN\r
      NEW.teacher_id := NEW.teacher_user_id;\r
    END IF;\r
  END IF;\r
  RETURN NEW;\r
END;\r
$$ LANGUAGE plpgsql;\r
\r
DROP TRIGGER IF EXISTS trg_sync_timetable_entries_teacher ON public.timetable_entries;\r
CREATE TRIGGER trg_sync_timetable_entries_teacher\r
BEFORE INSERT OR UPDATE ON public.timetable_entries\r
FOR EACH ROW\r
EXECUTE FUNCTION public.sync_timetable_entries_teacher();\r
\r
\r
CREATE OR REPLACE FUNCTION public.sync_teacher_subject_assignments_teacher()\r
RETURNS TRIGGER AS $$\r
BEGIN\r
  IF TG_OP = 'INSERT' THEN\r
    IF NEW.teacher_id IS NULL AND NEW.teacher_user_id IS NOT NULL THEN\r
      NEW.teacher_id := NEW.teacher_user_id;\r
    ELSIF NEW.teacher_user_id IS NULL AND NEW.teacher_id IS NOT NULL THEN\r
      NEW.teacher_user_id := NEW.teacher_id;\r
    END IF;\r
  ELSIF TG_OP = 'UPDATE' THEN\r
    IF NEW.teacher_id IS DISTINCT FROM OLD.teacher_id THEN\r
      NEW.teacher_user_id := NEW.teacher_id;\r
    ELSIF NEW.teacher_user_id IS DISTINCT FROM OLD.teacher_user_id THEN\r
      NEW.teacher_id := NEW.teacher_user_id;\r
    END IF;\r
  END IF;\r
  RETURN NEW;\r
END;\r
$$ LANGUAGE plpgsql;\r
\r
DROP TRIGGER IF EXISTS trg_sync_teacher_subject_assignments_teacher ON public.teacher_subject_assignments;\r
CREATE TRIGGER trg_sync_teacher_subject_assignments_teacher\r
BEFORE INSERT OR UPDATE ON public.teacher_subject_assignments\r
FOR EACH ROW\r
EXECUTE FUNCTION public.sync_teacher_subject_assignments_teacher();\r
\r
-- 22. Enable Row Level Security (RLS) on newly created tables\r
ALTER TABLE public.cleared_conversations ENABLE ROW LEVEL SECURITY;\r
ALTER TABLE public.fee_reminders ENABLE ROW LEVEL SECURITY;\r
ALTER TABLE public.ai_timetable_suggestions ENABLE ROW LEVEL SECURITY;\r
ALTER TABLE public.parent_notification_preferences ENABLE ROW LEVEL SECURITY;\r
ALTER TABLE public.timetable_period_logs ENABLE ROW LEVEL SECURITY;\r
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;\r
ALTER TABLE public.school_bootstrap ENABLE ROW LEVEL SECURITY;\r
\r
-- 23. Create basic RLS Policies for new tables\r
DROP POLICY IF EXISTS "Users can view own cleared conversations" ON public.cleared_conversations;\r
CREATE POLICY "Users can view own cleared conversations" ON public.cleared_conversations \r
  FOR SELECT USING (user_id = auth.uid());\r
\r
DROP POLICY IF EXISTS "Users can clear conversations" ON public.cleared_conversations;\r
CREATE POLICY "Users can clear conversations" ON public.cleared_conversations \r
  FOR INSERT WITH CHECK (user_id = auth.uid());\r
\r
DROP POLICY IF EXISTS "Users can undelete conversations" ON public.cleared_conversations;\r
CREATE POLICY "Users can undelete conversations" ON public.cleared_conversations \r
  FOR DELETE USING (user_id = auth.uid());\r
\r
DROP POLICY IF EXISTS "School members can view fee reminders" ON public.fee_reminders;\r
CREATE POLICY "School members can view fee reminders" ON public.fee_reminders \r
  FOR SELECT USING (true); -- Or check via is_school_member if function exists\r
\r
DROP POLICY IF EXISTS "School members can manage fee reminders" ON public.fee_reminders;\r
CREATE POLICY "School members can manage fee reminders" ON public.fee_reminders \r
  FOR ALL USING (true);\r
\r
DROP POLICY IF EXISTS "School members can view AI timetable suggestions" ON public.ai_timetable_suggestions;\r
CREATE POLICY "School members can view AI timetable suggestions" ON public.ai_timetable_suggestions \r
  FOR SELECT USING (true);\r
\r
DROP POLICY IF EXISTS "School members can manage AI timetable suggestions" ON public.ai_timetable_suggestions;\r
CREATE POLICY "School members can manage AI timetable suggestions" ON public.ai_timetable_suggestions \r
  FOR ALL USING (true);\r
\r
DROP POLICY IF EXISTS "Users can manage own notification preferences" ON public.parent_notification_preferences;\r
CREATE POLICY "Users can manage own notification preferences" ON public.parent_notification_preferences \r
  FOR ALL USING (user_id = auth.uid());\r
\r
DROP POLICY IF EXISTS "School members can view timetable period logs" ON public.timetable_period_logs;\r
CREATE POLICY "School members can view timetable period logs" ON public.timetable_period_logs \r
  FOR SELECT USING (true);\r
\r
DROP POLICY IF EXISTS "School members can manage timetable period logs" ON public.timetable_period_logs;\r
CREATE POLICY "School members can manage timetable period logs" ON public.timetable_period_logs \r
  FOR ALL USING (true);\r
\r
DROP POLICY IF EXISTS "School members can view audit logs" ON public.audit_logs;\r
CREATE POLICY "School members can view audit logs" ON public.audit_logs \r
  FOR SELECT USING (true);\r
\r
DROP POLICY IF EXISTS "School members can manage audit logs" ON public.audit_logs;\r
CREATE POLICY "School members can manage audit logs" ON public.audit_logs \r
  FOR ALL USING (true);\r
\r
DROP POLICY IF EXISTS "School members can view school bootstrap" ON public.school_bootstrap;\r
CREATE POLICY "School members can view school bootstrap" ON public.school_bootstrap \r
  FOR SELECT USING (true);\r
\r
DROP POLICY IF EXISTS "School members can manage school bootstrap" ON public.school_bootstrap;\r
CREATE POLICY "School members can manage school bootstrap" ON public.school_bootstrap \r
  FOR ALL USING (true);\r
\r
-- 24. Recreate View public.student_fee_ledger\r
DROP VIEW IF EXISTS public.student_fee_ledger;\r
CREATE VIEW public.student_fee_ledger \r
WITH (security_invoker = true) AS\r
SELECT \r
  s.id AS student_id,\r
  s.school_id,\r
  s.first_name,\r
  s.last_name,\r
  s.student_code,\r
  COALESCE(inv.total_invoiced, 0) AS total_invoiced,\r
  COALESCE(pay.total_paid, 0) AS total_paid,\r
  COALESCE(inv.total_invoiced, 0) - COALESCE(pay.total_paid, 0) AS outstanding_balance,\r
  COALESCE(inv.invoice_count, 0) AS invoice_count,\r
  COALESCE(pay.payment_count, 0) AS payment_count,\r
  COALESCE(inv.overdue_amount, 0) AS overdue_amount,\r
  COALESCE(inv.overdue_count, 0) AS overdue_count\r
FROM public.students s\r
LEFT JOIN LATERAL (\r
  SELECT \r
    SUM(fi.total_amount) AS total_invoiced,\r
    COUNT(fi.id) AS invoice_count,\r
    SUM(CASE WHEN fi.status = 'overdue' OR (fi.status != 'paid' AND fi.due_date < CURRENT_DATE) THEN fi.total_amount ELSE 0 END) AS overdue_amount,\r
    COUNT(CASE WHEN fi.status = 'overdue' OR (fi.status != 'paid' AND fi.due_date < CURRENT_DATE) THEN 1 END) AS overdue_count\r
  FROM public.fee_invoices fi\r
  WHERE fi.student_id = s.id AND fi.school_id = s.school_id\r
) inv ON true\r
LEFT JOIN LATERAL (\r
  SELECT \r
    SUM(fp.amount) AS total_paid,\r
    COUNT(fp.id) AS payment_count\r
  FROM public.fee_payments fp\r
  JOIN public.fee_invoices fi ON fi.id = fp.invoice_id\r
  WHERE fi.student_id = s.id AND fp.school_id = s.school_id AND fp.status = 'success'\r
) pay ON true;\r
\r
-- 25. Grant Select access to the view\r
GRANT SELECT ON public.student_fee_ledger TO authenticated;\r
\r
-- 26. Notify schema cache reload\r
NOTIFY pgrst, 'reload schema';\r
`;export{e as default};
