function s(r,t){if(!t)return"";if(t.startsWith("http://")||t.startsWith("https://")||t.startsWith("blob:"))return t;const e=t.replace(/^\//,"");return`/api/storage/files/${r}/${e}`}export{s as g};
