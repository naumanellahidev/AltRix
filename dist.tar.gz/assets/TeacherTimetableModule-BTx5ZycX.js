import{j as e,r,ad as je,aO as Je,R as et,v as tt,X as st,Y as at,T as nt,x as ot,C as rt,D as ye,y as we,z as ve,F as Ne,H as it,B as M,K as L,d as N,ae as lt,al as ct,aN as dt}from"./index-DZWmjE4u.js";import{q as Z,a5 as mt,f as ut,g as ht}from"./role-navigation-BcPViG7L.js";import{W as pt}from"./wifi-off-CTpF2WKF.js";import{C as G,a as X,b as K,c as Q}from"./card-Udt4CNEl.js";import{P as Se}from"./PeriodTimetableGrid-B68dOmxn.js";import{A as ft,a as xt,b as gt}from"./alert-DBU-q_F3.js";import{T as _t}from"./triangle-alert-CozouZ9H.js";import{B as j}from"./badge-C5digdRZ.js";import{C as ke}from"./clock-W0yZ8G1D.js";import{T as bt}from"./textarea-DzhxQl92.js";import{I as jt}from"./input-CxvIKCzq.js";import{L as pe}from"./label-BjgDmczO.js";import{B as yt}from"./book-open-DToidAhB.js";import{U as De}from"./GlobalCommandPalette-CAx4iHkg.js";import{M as wt}from"./map-pin-CKEaED0F.js";import{S as vt,a as Nt,b as St,c as kt,d as fe}from"./select-DQlVLbvo.js";import{u as Dt}from"./useConflictDetection-N4zyv923.js";import{C as Ct}from"./coffee-6CDmY1JI.js";import{C as Tt}from"./calendar-BkzwlHAd.js";import{F as Mt}from"./file-text-CKiMPbqd.js";import{D as Et}from"./download-Cn9zQcDp.js";import"./vendor-pdf-zip-0uPSLZ2M.js";import"./index-DWUFM-Ru.js";import"./index-CjAAmsIY.js";import"./chevron-right-DachCdjj.js";import"./switch-CNnSfOqB.js";import"./index-vR3SEcJd.js";import"./settings-2-CamTJX_I.js";import"./smartphone-D1S8sMdV.js";import"./award-DkC761j_.js";import"./credit-card-Dw7z7RpJ.js";import"./megaphone-CRux5z7k.js";import"./format-CoTCFH3j.js";import"./inbox-CZo5mSk8.js";import"./octagon-alert-CwmnOc8a.js";import"./external-link-e6Y-ZhOn.js";import"./user-plus-CmJxNf40.js";import"./shield-alert-vQoCvtBl.js";function $t({isUsingCache:n=!1}){const a=typeof navigator<"u"?!navigator.onLine:!1;return!a&&!n?null:e.jsxs("div",{className:"rounded-2xl bg-warning/10 border border-warning/20 p-3 text-sm text-warning text-center",children:[e.jsx(pt,{className:"inline-block h-4 w-4 mr-2"}),a?"Offline Mode — Showing cached data":"Showing cached data"]})}function At({conflicts:n,entryLabels:a}){const o=Array.from(n.entries()).filter(([,l])=>l.length>0);if(o.length===0)return null;const u=o.filter(([,l])=>l.some(f=>f.type==="teacher")),t=o.filter(([,l])=>l.some(f=>f.type==="room"));return e.jsxs(ft,{variant:"destructive",className:"border-destructive/50 bg-destructive/10",children:[e.jsx(_t,{className:"h-4 w-4"}),e.jsx(xt,{children:"Schedule Conflicts Detected"}),e.jsxs(gt,{className:"mt-2 space-y-2",children:[u.length>0&&e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"Teacher double-bookings:"})," ",e.jsxs("span",{className:"text-sm",children:[u.length," period",u.length>1?"s":""," where you're assigned to multiple sections simultaneously."]})]}),t.length>0&&e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"Room collisions:"})," ",e.jsxs("span",{className:"text-sm",children:[t.length," period",t.length>1?"s":""," where the same room is used by multiple sections."]})]}),e.jsx("p",{className:"text-xs text-muted-foreground mt-1",children:"Please contact your administrator to resolve these conflicts."})]})]})}const It=[{id:-1,label:"All",short:"All"},{id:0,label:"Sunday",short:"Su"},{id:1,label:"Monday",short:"Mo"},{id:2,label:"Tuesday",short:"Tu"},{id:3,label:"Wednesday",short:"We"},{id:4,label:"Thursday",short:"Th"},{id:5,label:"Friday",short:"Fr"},{id:6,label:"Saturday",short:"Sa"}];function Lt({selectedDay:n,onSelectDay:a,todayHighlight:o=!0}){const u=r.useMemo(()=>new Date().getDay(),[]);return e.jsxs(Z,{className:"w-full",children:[e.jsx("div",{className:"flex gap-1 sm:gap-1.5 pb-2",children:It.map(t=>{const l=n===t.id,f=t.id===u&&o;return e.jsxs("button",{onClick:()=>a(t.id),className:je("relative shrink-0 px-2 sm:px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all",l?"bg-primary text-primary-foreground shadow-sm":"bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground",f&&!l&&"ring-2 ring-primary/50"),children:[e.jsx("span",{className:"hidden md:inline",children:t.label}),e.jsx("span",{className:"md:hidden",children:t.short}),f&&e.jsx("span",{className:"absolute -top-0.5 -right-0.5 h-1.5 w-1.5 sm:h-2 sm:w-2 rounded-full bg-primary animate-pulse"})]},t.id)})}),e.jsx(mt,{orientation:"horizontal",className:"h-1.5"})]})}function q(n){if(!n)return null;const[a,o]=n.split(":").map(Number);return isNaN(a)||isNaN(o)?null:{hours:a,minutes:o}}function xe(){const n=new Date;return n.getHours()*60+n.getMinutes()}function Pt(n){const[a,o]=r.useState(xe);return r.useEffect(()=>{const t=setInterval(()=>{o(xe())},6e4);return()=>clearInterval(t)},[]),r.useMemo(()=>{const t=new Date().getDay();let l=null,f=null,h=null;for(let m=0;m<n.length;m++){const i=n[m],c=q(i.start_time),_=q(i.end_time);if(c&&_){const g=c.hours*60+c.minutes,y=_.hours*60+_.minutes;if(a>=g&&a<y){if(l=i,m+1<n.length){f=n[m+1];const p=q(n[m+1].start_time);p&&(h=p.hours*60+p.minutes-a)}break}a<g&&!f&&(f=i,h=g-a)}}return{currentPeriod:l,nextPeriod:f,minutesUntilNext:h,dayOfWeek:t}},[n,a])}function Ot({periods:n,className:a}){const{currentPeriod:o,nextPeriod:u,minutesUntilNext:t}=Pt(n);return!o&&!u?null:e.jsxs("div",{className:je("flex flex-col sm:flex-row flex-wrap items-start sm:items-center gap-2 sm:gap-3",a),children:[o&&e.jsxs("div",{className:"flex items-center gap-1.5 sm:gap-2 rounded-lg sm:rounded-xl bg-primary/10 px-2 sm:px-3 py-1.5 sm:py-2",children:[e.jsx(ke,{className:"h-3.5 w-3.5 sm:h-4 sm:w-4 text-primary animate-pulse shrink-0"}),e.jsxs("span",{className:"text-xs sm:text-sm font-medium",children:["Now: ",e.jsx("span",{className:"text-primary",children:o.label})]})]}),u&&t!==null&&e.jsxs("div",{className:"flex items-center gap-1.5 sm:gap-2 rounded-lg sm:rounded-xl bg-muted px-2 sm:px-3 py-1.5 sm:py-2",children:[e.jsx(Je,{className:"h-3.5 w-3.5 sm:h-4 sm:w-4 text-muted-foreground shrink-0"}),e.jsxs("span",{className:"text-xs sm:text-sm text-muted-foreground",children:["Next: ",u.label,t>0&&e.jsxs(j,{variant:"outline",className:"ml-1.5 sm:ml-2 text-[10px] sm:text-xs px-1.5",children:[t,"m"]})]})]})]})}const Rt=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],ge=["hsl(var(--chart-1))","hsl(var(--chart-2))","hsl(var(--chart-3))","hsl(var(--chart-4))","hsl(var(--chart-5))","hsl(var(--primary))","hsl(var(--accent))"];function Ut(n,a){let o=0;const u=new Set(a);for(const t of n)if(!(!u.has(t.id)||t.is_break))if(t.start_time&&t.end_time){const[l,f]=t.start_time.split(":").map(Number),[h,m]=t.end_time.split(":").map(Number),i=l*60+f,c=h*60+m;c>i&&(o+=c-i)}else o+=45;return Number((o/60).toFixed(2))}function V(n){return n.toFixed(2)}function zt({entries:n,periods:a}){const o=r.useMemo(()=>{var m;const h={};for(let i=0;i<7;i++)h[i]=[];for(const i of n)i.subject_name&&((m=h[i.day_of_week])==null||m.push(i.period_id));return Rt.map((i,c)=>({name:i,periods:h[c].length,hours:Ut(a,h[c])}))},[n,a]),u=r.useMemo(()=>n.filter(h=>h.subject_name).length,[n]),t=r.useMemo(()=>Number(o.reduce((h,m)=>h+m.hours,0).toFixed(2)),[o]),l=r.useMemo(()=>{const h=o.filter(m=>m.periods>0).length;return h>0?Number((t/h).toFixed(2)):0},[o,t]),f=new Date().getDay();return e.jsxs(G,{className:"no-print",children:[e.jsx(X,{className:"pb-2 px-3 sm:px-6",children:e.jsxs("div",{className:"flex flex-col sm:flex-row sm:items-center justify-between gap-2",children:[e.jsx(K,{className:"text-sm font-medium",children:"Weekly Workload"}),e.jsxs("div",{className:"flex flex-wrap gap-1.5 sm:gap-2",children:[e.jsxs(j,{variant:"secondary",className:"text-xs",children:[u," periods"]}),e.jsxs(j,{variant:"outline",className:"text-xs",children:[V(t),"h"]}),e.jsxs(j,{variant:"outline",className:"text-xs",children:[V(l),"h/day"]})]})]})}),e.jsx(Q,{className:"px-2 sm:px-6 pb-3",children:e.jsx("div",{className:"h-[160px] sm:h-[180px] w-full",children:e.jsx(et,{width:"100%",height:"100%",children:e.jsxs(tt,{data:o,margin:{top:10,right:5,left:0,bottom:5},children:[e.jsx(st,{dataKey:"name",tick:{fontSize:10},tickLine:!1,axisLine:!1,interval:0,height:25,dy:5}),e.jsx(at,{tick:{fontSize:10},tickLine:!1,axisLine:!1,width:30,tickFormatter:h=>h.toFixed(1)}),e.jsx(nt,{content:({active:h,payload:m})=>{if(h&&(m!=null&&m.length)){const i=m[0].payload;return e.jsxs("div",{className:"rounded-lg bg-popover px-3 py-2 text-sm shadow-md border",children:[e.jsx("p",{className:"font-medium",children:i.name}),e.jsxs("p",{className:"text-muted-foreground",children:[i.periods," period",i.periods!==1?"s":""," • ",V(i.hours),"h"]})]})}return null}}),e.jsx(ot,{dataKey:"hours",radius:[4,4,0,0],children:o.map((h,m)=>e.jsx(rt,{fill:m===f?"hsl(var(--primary))":ge[m%ge.length],opacity:m===f?1:.7},`cell-${m}`))})]})})})})]})}function Ft({open:n,onOpenChange:a,schoolId:o,entryId:u,periodInfo:t,existingNote:l,onSaved:f}){const[h,m]=r.useState((l==null?void 0:l.topic_covered)??""),[i,c]=r.useState((l==null?void 0:l.notes)??""),[_,g]=r.useState(!1);r.useEffect(()=>{m((l==null?void 0:l.topic_covered)??""),c((l==null?void 0:l.notes)??"")},[l,n]);const y=async()=>{var p;if(!h.trim()){L.error("Please enter a topic covered");return}g(!0);try{const{data:D}=await N.auth.getUser(),C=(p=D.user)==null?void 0:p.id;if(l){const{error:S}=await N.from("timetable_period_logs").update({topic_covered:h.trim(),notes:i.trim()||null,updated_at:new Date().toISOString()}).eq("id",l.id);if(S)throw S;L.success("Period log updated")}else{const{error:S}=await N.from("timetable_period_logs").insert({school_id:o,timetable_entry_id:u,teacher_user_id:C,topic_covered:h.trim(),notes:i.trim()||null,logged_at:new Date().toISOString()});if(S)throw S;L.success("Period log saved")}f(),a(!1)}catch(D){console.error("Error saving period log:",D),L.error(D.message||"Failed to save")}finally{g(!1)}};return e.jsx(ye,{open:n,onOpenChange:a,children:e.jsxs(we,{className:"max-w-[95vw] sm:max-w-md max-h-[90vh] p-0",children:[e.jsx(ve,{className:"px-4 sm:px-6 pt-4 sm:pt-6 pb-2",children:e.jsxs(Ne,{className:"flex items-center gap-2 text-base sm:text-lg",children:[e.jsx(yt,{className:"h-4 w-4 sm:h-5 sm:w-5 text-primary shrink-0"}),"Period Log"]})}),e.jsx(Z,{className:"max-h-[60vh] px-4 sm:px-6",children:e.jsxs("div",{className:"space-y-4 pb-4",children:[e.jsxs("div",{className:"flex flex-wrap gap-1.5 sm:gap-2 rounded-lg sm:rounded-xl bg-muted/50 p-2.5 sm:p-3",children:[e.jsxs(j,{variant:"secondary",className:"gap-1 text-xs",children:[e.jsx(ke,{className:"h-3 w-3"}),t.day_label," • ",t.period_label]}),t.subject_name&&e.jsx(j,{variant:"outline",className:"text-xs",children:t.subject_name}),t.section_label&&e.jsxs(j,{variant:"outline",className:"gap-1 text-xs",children:[e.jsx(De,{className:"h-3 w-3"}),t.section_label]}),t.room&&e.jsxs(j,{variant:"outline",className:"gap-1 text-xs",children:[e.jsx(wt,{className:"h-3 w-3"}),t.room]})]}),e.jsxs("div",{className:"space-y-1.5 sm:space-y-2",children:[e.jsx(pe,{htmlFor:"topic",className:"text-sm",children:"Topic Covered *"}),e.jsx(jt,{id:"topic",placeholder:"e.g., Chapter 5: Quadratic Equations",value:h,onChange:p=>m(p.target.value),className:"text-sm"})]}),e.jsxs("div",{className:"space-y-1.5 sm:space-y-2",children:[e.jsx(pe,{htmlFor:"notes",className:"text-sm",children:"Additional Notes"}),e.jsx(bt,{id:"notes",placeholder:"Observations, homework assigned, student questions...",value:i,onChange:p=>c(p.target.value),rows:3,className:"text-sm resize-none"})]})]})}),e.jsxs(it,{className:"px-4 sm:px-6 pb-4 sm:pb-6 pt-2 flex-col-reverse sm:flex-row gap-2",children:[e.jsx(M,{variant:"outline",onClick:()=>a(!1),className:"w-full sm:w-auto",children:"Cancel"}),e.jsx(M,{onClick:y,disabled:_,className:"w-full sm:w-auto",children:_?"Saving...":l?"Update":"Save Log"})]})]})})}function Bt({open:n,onOpenChange:a,sectionLabel:o,periods:u,entries:t}){return e.jsx(ye,{open:n,onOpenChange:a,children:e.jsxs(we,{className:"max-w-[95vw] sm:max-w-6xl max-h-[90vh] p-0",children:[e.jsx(ve,{className:"px-4 sm:px-6 pt-4 sm:pt-6 pb-2",children:e.jsxs(Ne,{className:"flex items-center gap-2 text-base sm:text-lg",children:[e.jsx(De,{className:"h-4 w-4 sm:h-5 sm:w-5 shrink-0"}),e.jsx("span",{className:"truncate",children:"Section Timetable"}),e.jsx(j,{variant:"secondary",className:"ml-1 sm:ml-2 text-xs shrink-0",children:o})]})}),e.jsx(Z,{className:"flex-1 px-4 sm:px-6 pb-4 sm:pb-6",children:e.jsx("div",{className:"min-w-0",children:t.length===0?e.jsx("p",{className:"text-sm text-muted-foreground text-center py-8",children:"No timetable entries found for this section."}):e.jsx("div",{className:"overflow-x-auto",children:e.jsx("div",{className:"min-w-[600px]",children:e.jsx(Se,{periods:u,entries:t,density:"compact",stickyDayColumn:!1})})})})})]})})}const Wt=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];function _e(n){return n?String(n).slice(0,5):""}function Ce(n){const{teacherName:a,schoolName:o,periods:u,entries:t,generatedAt:l}=n,f=new Map;for(const c of t)f.set(`${c.day_of_week}:${c.period_id}`,c);const h=u.filter(c=>!c.is_break),m=h.map(c=>`
      <th class="period-header">
        <div class="period-label">${c.label}</div>
        <div class="period-time">${_e(c.start_time)}${c.start_time&&c.end_time?" - ":""}${_e(c.end_time)}</div>
      </th>
    `).join(""),i=Wt.map((c,_)=>{const g=h.map(y=>{const p=f.get(`${_}:${y.id}`);return!p||!p.subject_name?'<td class="cell empty">—</td>':`
          <td class="cell">
            <div class="subject">${p.subject_name}</div>
            ${p.section_label?`<div class="section">${p.section_label}</div>`:""}
            ${p.room?`<div class="room">Room: ${p.room}</div>`:""}
          </td>
        `}).join("");return`
      <tr>
        <td class="day-cell">${c}</td>
        ${g}
      </tr>
    `}).join("");return`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Weekly Timetable - ${a}</title>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      font-size: 11px;
      line-height: 1.4;
      color: #1a1a1a;
      background: #fff;
      padding: 20px;
    }
    .header {
      text-align: center;
      margin-bottom: 24px;
      padding-bottom: 16px;
      border-bottom: 2px solid #e5e5e5;
    }
    .school-name {
      font-size: 18px;
      font-weight: 700;
      color: #333;
      margin-bottom: 4px;
    }
    .title {
      font-size: 24px;
      font-weight: 700;
      color: #111;
      margin-bottom: 8px;
    }
    .teacher-name {
      font-size: 16px;
      font-weight: 600;
      color: #555;
      margin-bottom: 4px;
    }
    .generated-date {
      font-size: 10px;
      color: #888;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    th, td {
      border: 1px solid #ddd;
      padding: 8px 6px;
      text-align: left;
      vertical-align: top;
    }
    th {
      background: #f8f9fa;
      font-weight: 600;
    }
    .day-header {
      width: 70px;
      background: #f0f0f0;
    }
    .period-header {
      min-width: 100px;
      text-align: center;
    }
    .period-label {
      font-weight: 600;
      font-size: 11px;
    }
    .period-time {
      font-size: 9px;
      color: #666;
      margin-top: 2px;
    }
    .day-cell {
      font-weight: 600;
      background: #f8f9fa;
      text-align: center;
      vertical-align: middle;
    }
    .cell {
      min-height: 50px;
      font-size: 10px;
    }
    .cell.empty {
      color: #ccc;
      text-align: center;
      vertical-align: middle;
    }
    .subject {
      font-weight: 600;
      font-size: 11px;
      color: #333;
      margin-bottom: 2px;
    }
    .section {
      font-size: 9px;
      color: #666;
      margin-bottom: 1px;
    }
    .room {
      font-size: 9px;
      color: #888;
    }
    .footer {
      text-align: center;
      font-size: 9px;
      color: #999;
      margin-top: 20px;
      padding-top: 12px;
      border-top: 1px solid #eee;
    }
    @media print {
      body {
        padding: 0;
        font-size: 10px;
      }
      .header {
        margin-bottom: 16px;
      }
      table {
        page-break-inside: auto;
      }
      tr {
        page-break-inside: avoid;
        page-break-after: auto;
      }
      @page {
        size: landscape;
        margin: 10mm;
      }
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="school-name">${o}</div>
    <div class="title">Weekly Teaching Schedule</div>
    <div class="teacher-name">${a}</div>
    <div class="generated-date">Generated: ${l}</div>
  </div>
  
  <table>
    <thead>
      <tr>
        <th class="day-header">Day</th>
        ${m}
      </tr>
    </thead>
    <tbody>
      ${i}
    </tbody>
  </table>
  
  <div class="footer">
    This timetable was automatically generated. For any discrepancies, please contact the administration.
  </div>
</body>
</html>
  `.trim()}function Ht(n){const a=Ce(n),o=window.open("","_blank");o&&(o.document.write(a),o.document.close(),setTimeout(()=>{o.print()},300))}function qt(n){const a=Ce(n),o=new Blob([a],{type:"text/html;charset=utf-8;"}),u=URL.createObjectURL(o),t=document.createElement("a");t.href=u;const l=n.teacherName.replace(/[^a-z0-9]+/gi,"_").toLowerCase();t.download=`Timetable_${l}.html`,document.body.appendChild(t),t.click(),document.body.removeChild(t),URL.revokeObjectURL(u)}function Y(n,a){if(!a)return"";const[o,u]=a.split(":").map(Number),t=new Date(n);t.setHours(o,u,0,0);const l=t.getFullYear(),f=String(t.getMonth()+1).padStart(2,"0"),h=String(t.getDate()).padStart(2,"0"),m=String(t.getHours()).padStart(2,"0"),i=String(t.getMinutes()).padStart(2,"0");return`${l}${f}${h}T${m}${i}00`}function I(n){return n.replace(/\\/g,"\\\\").replace(/;/g,"\\;").replace(/,/g,"\\,").replace(/\n/g,"\\n")}function Vt(){return`${Date.now()}-${Math.random().toString(36).substr(2,9)}@eduverse.app`}function Yt(n,a){const o=new Date(a),u=o.getDay(),t=(n-u+7)%7;return o.setDate(o.getDate()+(t===0?0:t)),o}function Gt(n){const{teacherName:a,schoolName:o,periods:u,entries:t,weeksAhead:l=4}=n,f=new Map(u.map(i=>[i.id,i])),h=new Date,m=["BEGIN:VCALENDAR","VERSION:2.0","PRODID:-//EDUVERSE//Timetable Export//EN","CALSCALE:GREGORIAN","METHOD:PUBLISH",`X-WR-CALNAME:${I(a)} - Timetable`,`X-WR-CALDESC:Weekly teaching schedule from ${I(o)}`];for(const i of t){if(!i.subject_name)continue;const c=f.get(i.period_id);if(!(!c||!c.start_time||!c.end_time))for(let _=0;_<l;_++){const g=Yt(i.day_of_week,h);g.setDate(g.getDate()+_*7);const y=Y(g,c.start_time),p=Y(g,c.end_time);if(!y||!p)continue;const D=i.subject_name,C=i.room||"",S=[i.section_label?`Section: ${i.section_label}`:"",i.teacher_name?`Teacher: ${i.teacher_name}`:"",`Period: ${c.label}`].filter(Boolean).join("\\n");m.push("BEGIN:VEVENT",`UID:${Vt()}`,`DTSTAMP:${Y(h,"00:00")}00Z`,`DTSTART:${y}`,`DTEND:${p}`,`SUMMARY:${I(D)}`,C?`LOCATION:${I(C)}`:"",`DESCRIPTION:${S}`,`CATEGORIES:Teaching,${I(o)}`,"STATUS:CONFIRMED","END:VEVENT")}}return m.push("END:VCALENDAR"),m.filter(Boolean).join(`\r
`)}function Xt(n){const a=Gt(n),o=new Blob([a],{type:"text/calendar;charset=utf-8"}),u=URL.createObjectURL(o),t=document.createElement("a");t.href=u;const l=n.teacherName.replace(/[^a-z0-9]+/gi,"_").toLowerCase();t.download=`Timetable_${l}.ics`,document.body.appendChild(t),t.click(),document.body.removeChild(t),URL.revokeObjectURL(u)}const be=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];function Ls(){const{schoolSlug:n}=lt(),a=ct(n),o=r.useMemo(()=>a.status==="ready"?a.schoolId:null,[a.status,a.schoolId]),u=r.useMemo(()=>a.status==="ready"?a.school.name:"School",[a.status,a.school]),[t,l]=r.useState([]),[f,h]=r.useState([]),[m,i]=r.useState([]),[c,_]=r.useState("mine"),[g,y]=r.useState(-1),[p,D]=r.useState([]),[C,S]=r.useState([]),[J,Te]=r.useState([]),[P,ee]=r.useState([]),[Kt,Me]=r.useState(null),[E,Ee]=r.useState("Teacher"),[$e,z]=r.useState(!0),[Ae,te]=r.useState(!1),[k,Ie]=r.useState(null),[Le,se]=r.useState(!1),[A,Pe]=r.useState(null),Oe=r.useMemo(()=>{const s=new Map;for(const d of P)s.set(d.id,d.label);return s},[P]),ae=Dt(m,"",Oe),ne=r.useMemo(()=>{const s=new Map,d=c==="mine"?t:f;for(const v of d){const $=ae.get(v.id);$&&$.length>0&&s.set(v.id,$)}return s},[ae,t,f,c]),Re=r.useMemo(()=>{const s=new Map,d=c==="mine"?t:f;for(const v of d)s.set(v.id,`${v.subject_name} (${v.section_label||"Unknown section"})`);return s},[t,f,c]),Ue=r.useMemo(()=>{const s=new Map;for(const d of p)s.set(d.id,d.label);return s},[p]),ze=r.useMemo(()=>{const s=new Map;for(const d of C)s.set(d.timetable_entry_id,d);return s},[C]),O=r.useCallback(async()=>{var ue,he;if(a.status!=="ready")return;z(!0);const{data:s}=await N.auth.getUser(),d=((ue=s.user)==null?void 0:ue.id)??null;if(!d){console.error("TeacherTimetableModule: No user ID found"),z(!1);return}Me(d);const[{data:v},{data:$},{data:F},{data:Ke}]=await Promise.all([N.from("timetable_periods").select("id,label,sort_order,start_time,end_time,is_break").eq("school_id",a.schoolId).order("sort_order",{ascending:!0}),N.from("school_user_directory").select("user_id,display_name,email").eq("school_id",a.schoolId),N.from("timetable_entries").select("id,subject_name,day_of_week,period_id,room,teacher_user_id,class_section_id").eq("school_id",a.schoolId),N.from("timetable_period_logs").select("id,timetable_entry_id,topic_covered,notes,logged_at").eq("school_id",a.schoolId).eq("teacher_user_id",d).order("logged_at",{ascending:!1})]);D(v??[]),Te($??[]),i(F??[]),S(Ke??[]);const B=($??[]).find(x=>x.user_id===d);B&&Ee(B.display_name||B.email||"Teacher");const{data:Qe}=await N.from("teacher_assignments").select("class_section_id").eq("school_id",a.schoolId).eq("teacher_user_id",d),U=(Qe??[]).map(x=>x.class_section_id).filter(Boolean),ie=new Set;for(const x of F??[])x.class_section_id&&ie.add(x.class_section_id);const le=Array.from(new Set([...U,...Array.from(ie)])),W=new Map;if(le.length>0){const{data:x}=await N.from("class_sections").select("id, name, academic_classes(name)").in("id",le);for(const H of x??[])W.set(H.id,`${((he=H.academic_classes)==null?void 0:he.name)||""} • ${H.name}`.trim())}U.length>0?ee(U.map(x=>({id:x,label:W.get(x)??x})).filter(x=>!!x.label)):ee([]);const ce=(F??[]).map(x=>({id:x.id,subject_name:x.subject_name,day_of_week:x.day_of_week,period_id:x.period_id,room:x.room,teacher_user_id:x.teacher_user_id,class_section_id:x.class_section_id,section_label:x.class_section_id?W.get(x.class_section_id)??null:null})),de=ce.filter(x=>x.teacher_user_id===d),Ze=new Set(U),me=ce.filter(x=>x.class_section_id&&Ze.has(x.class_section_id));l(de),h(me),de.length===0&&me.length>0&&_("sections"),z(!1)},[a.status,a.schoolId]);r.useEffect(()=>{O()},[O]),ut({channel:`teacher-timetable-${o}`,table:"timetable_entries",filter:o?`school_id=eq.${o}`:void 0,enabled:!!o,onChange:()=>void O()});const w=r.useMemo(()=>{const s=new Map;for(const d of J)s.set(d.user_id,d.display_name??d.email);return s},[J]),T=r.useMemo(()=>{const s=c==="mine"?t:f;return g===-1?s:s.filter(d=>d.day_of_week===g)},[c,t,f,g]),Fe=r.useMemo(()=>T.map(s=>({id:s.id,day_of_week:s.day_of_week,period_id:s.period_id,subject_name:s.subject_name,room:s.room,teacher_name:s.teacher_user_id?w.get(s.teacher_user_id)??null:null,section_label:s.section_label})),[T,w]),b=c==="mine"?t:f,Be=r.useMemo(()=>new Set(b.map(s=>s.class_section_id).filter(Boolean)).size,[b]),We=b.length,He=r.useMemo(()=>new Set(b.map(s=>s.subject_name).filter(Boolean)).size,[b]),R=ne.size,qe=r.useCallback(()=>{const s={teacherName:E,schoolName:u,periods:p,entries:b.map(d=>({day_of_week:d.day_of_week,period_id:d.period_id,subject_name:d.subject_name,room:d.room,section_label:d.section_label,teacher_name:d.teacher_user_id?w.get(d.teacher_user_id)??null:null})),generatedAt:new Date().toLocaleString()};Ht(s)},[E,u,p,b,w]),Ve=r.useCallback(()=>{const s={teacherName:E,schoolName:u,periods:p,entries:b.map(d=>({day_of_week:d.day_of_week,period_id:d.period_id,subject_name:d.subject_name,room:d.room,section_label:d.section_label,teacher_name:d.teacher_user_id?w.get(d.teacher_user_id)??null:null})),generatedAt:new Date().toLocaleString()};qt(s)},[E,u,p,b,w]),Ye=r.useCallback(()=>{Xt({teacherName:E,schoolName:u,periods:p,entries:b.map(s=>({day_of_week:s.day_of_week,period_id:s.period_id,subject_name:s.subject_name,room:s.room,section_label:s.section_label,teacher_name:s.teacher_user_id?w.get(s.teacher_user_id)??null:null})),weeksAhead:4}),L.success("Calendar file downloaded! Import it to Google Calendar or Outlook.")},[E,u,p,b,w]),oe=s=>{Ie(s),te(!0)},Ge=s=>{Pe(s),se(!0)},Xe=r.useMemo(()=>A?m.filter(s=>s.class_section_id===A.id).map(s=>({id:s.id,day_of_week:s.day_of_week,period_id:s.period_id,subject_name:s.subject_name,room:s.room,teacher_name:s.teacher_user_id?w.get(s.teacher_user_id)??null:null,section_label:null})):[],[A,m,w]),re=typeof navigator<"u"?!navigator.onLine:!1;return $e&&!re?e.jsx("p",{className:"text-sm text-muted-foreground",children:"Loading..."}):e.jsxs("div",{className:"space-y-4",children:[re&&e.jsx($t,{isUsingCache:!0}),e.jsx(Ot,{periods:p,className:"no-print"}),R>0&&e.jsx(At,{conflicts:ne,entryLabels:Re}),e.jsx("div",{className:"no-print",children:e.jsx(Lt,{selectedDay:g,onSelectDay:y})}),e.jsxs("div",{className:"flex flex-wrap gap-3",children:[e.jsxs(j,{variant:"secondary",className:"text-sm",children:[We," periods"]}),e.jsxs(j,{variant:"secondary",className:"text-sm",children:[Be," sections"]}),e.jsxs(j,{variant:"secondary",className:"text-sm",children:[He," subjects"]}),p.some(s=>s.is_break)&&e.jsxs(j,{variant:"outline",className:"text-sm",children:[e.jsx(Ct,{className:"mr-1 h-3 w-3"}),p.filter(s=>s.is_break).length," breaks"]}),R>0&&e.jsxs(j,{variant:"destructive",className:"text-sm",children:[R," conflict",R>1?"s":""]})]}),e.jsxs("div",{className:"flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between no-print",children:[e.jsxs(vt,{value:c,onValueChange:s=>_(s),children:[e.jsx(Nt,{className:"w-full sm:w-[260px]",children:e.jsx(St,{})}),e.jsxs(kt,{children:[e.jsxs(fe,{value:"mine",children:["My periods (",t.length,")"]}),e.jsxs(fe,{value:"sections",children:["All assigned sections (",f.length,")"]})]})]}),e.jsxs("div",{className:"flex flex-wrap gap-2",children:[e.jsxs(M,{variant:"outline",size:"sm",onClick:Ye,disabled:b.length===0,children:[e.jsx(Tt,{className:"mr-2 h-4 w-4"})," Sync Calendar"]}),e.jsxs(M,{variant:"outline",size:"sm",onClick:qe,disabled:b.length===0,children:[e.jsx(Mt,{className:"mr-2 h-4 w-4"})," PDF"]}),e.jsxs(M,{variant:"outline",size:"sm",onClick:Ve,disabled:b.length===0,children:[e.jsx(Et,{className:"mr-2 h-4 w-4"})," HTML"]}),e.jsxs(M,{variant:"outline",size:"sm",onClick:()=>window.print(),children:[e.jsx(dt,{className:"mr-2 h-4 w-4"})," Print"]})]})]}),e.jsx(zt,{entries:b,periods:p}),P.length>0&&e.jsxs(G,{className:"no-print",children:[e.jsx(X,{className:"pb-2",children:e.jsx(K,{className:"text-sm font-medium text-muted-foreground",children:"My Assigned Sections (click to view full timetable)"})}),e.jsx(Q,{children:e.jsx("div",{className:"flex flex-wrap gap-2",children:P.map(s=>e.jsx(j,{variant:"outline",className:"cursor-pointer hover:bg-primary/10 transition-colors",onClick:()=>Ge(s),children:s.label},s.id))})})]}),e.jsxs(G,{className:"print-area",children:[e.jsx(X,{className:"no-print",children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx(K,{children:g===-1?"My Weekly Schedule":`${be[g]} Schedule`}),e.jsx("p",{className:"text-sm text-muted-foreground",children:c==="mine"?"Periods where you are the assigned teacher":"All periods in your assigned sections"})]}),c==="mine"&&T.length>0&&e.jsxs(M,{variant:"outline",size:"sm",onClick:()=>{const s=new Date().getDay(),d=T.find(v=>v.day_of_week===s);d?oe(d):T[0]&&oe(T[0])},children:[e.jsx(ht,{className:"mr-2 h-4 w-4"})," Log Period"]})]})}),e.jsx(Q,{children:T.length===0?e.jsx("p",{className:"text-sm text-muted-foreground",children:"No timetable entries found for this view."}):e.jsx(Se,{periods:p,entries:Fe})})]}),k&&o&&e.jsx(Ft,{open:Ae,onOpenChange:te,schoolId:o,entryId:k.id,periodInfo:{id:k.id,subject_name:k.subject_name,room:k.room,section_label:k.section_label,period_label:Ue.get(k.period_id)??"Period",day_label:be[k.day_of_week]??"Day"},existingNote:ze.get(k.id)??null,onSaved:O}),A&&e.jsx(Bt,{open:Le,onOpenChange:se,sectionLabel:A.label,periods:p,entries:Xe})]})}export{Ls as TeacherTimetableModule};
