import{j as t,ad as a}from"./index-cvQ-tfE3.js";function m({className:e,...s}){return t.jsx("div",{className:a("animate-pulse rounded-md bg-muted",e),...s})}export{m as S};
