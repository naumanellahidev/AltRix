import{_ as x}from"./vendor-pdf-zip-0uPSLZ2M.js";import{r as E}from"./index-cvQ-tfE3.js";function P(g){return new Promise(u=>{const t=document.createElement("iframe");t.setAttribute("aria-hidden","true"),t.style.position="fixed",t.style.right="0",t.style.bottom="0",t.style.width="820px",t.style.height="1160px",t.style.border="0",t.style.opacity="0",t.style.pointerEvents="none",t.style.zIndex="-1",document.body.appendChild(t);const a=Array.from(document.querySelectorAll('link[rel="stylesheet"], style')).map(l=>l.outerHTML).join(`
`),d=g.cloneNode(!0),y=`<!doctype html><html><head><meta charset="utf-8">
<base href="${document.baseURI}">
${a}
<style>
  /* Remove browser-default print headers (date, URL, "AltRix - Lovable" title bar)
     by zeroing @page margin, then re-add margins on the body so content still
     has breathing room. */
  @page { size: A4; margin: 0; }
  html, body { background: #ffffff !important; color: #0f172a !important; margin:0; padding:0; }
  body { font-family: Georgia, 'Times New Roman', serif; padding: 10mm; }
  [data-print="hide"], .no-print, [data-powered-by] { display: none !important; }
  @media print {
    html, body { background: #ffffff !important; }
    body { padding: 10mm; }
    .branded-doc, .letterhead { box-shadow: none !important; }
    table, tr, td, th, .avoid-break { page-break-inside: avoid !important; break-inside: avoid !important; }
  }
  :root, .dark { color-scheme: light !important; }
  * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
</style>
</head><body><div id="print-root"></div></body></html>`;t.srcdoc=y,t.onload=()=>{const l=t.contentDocument,r=l.getElementById("print-root");r.appendChild(l.adoptNode(d)),r.querySelectorAll('[data-print="hide"], .no-print, [data-powered-by]').forEach(e=>e.remove());const n=l.createTreeWalker(r,NodeFilter.SHOW_TEXT,null),p=[];let o=n.nextNode();for(;o;){const e=(o.nodeValue||"").toLowerCase().trim();(e.includes("powered by")||e.includes("altrix - lovable")||e.includes("altrix-lovable")||e.includes("altrix: powered by")||e.startsWith("issued:")||e.startsWith("issued on"))&&o.parentElement&&p.push(o.parentElement),o=n.nextNode()}p.forEach(e=>e.remove());const m=Array.from(r.querySelectorAll("img"));Promise.all(m.map(e=>new Promise(h=>{if(e.complete)return h();e.addEventListener("load",()=>h(),{once:!0}),e.addEventListener("error",()=>h(),{once:!0})}))).then(()=>u(t))}})}function W(){const g=E.useCallback(async(t,a)=>{const d=await P(t);try{const[{default:y},{default:l}]=await Promise.all([x(()=>import("./vendor-pdf-zip-0uPSLZ2M.js").then(i=>i.d),[]),x(()=>import("./vendor-pdf-zip-0uPSLZ2M.js").then(i=>i.j),[])]),r=d.contentDocument.getElementById("print-root").firstElementChild,n=await y(r,{scale:2,useCORS:!0,backgroundColor:"#ffffff",logging:!1,windowWidth:r.scrollWidth,windowHeight:r.scrollHeight}),p=n.toDataURL("image/jpeg",.95),o=new l({orientation:a.orientation||"portrait",unit:"mm",format:a.format||"a4"}),m=o.internal.pageSize.getWidth(),e=o.internal.pageSize.getHeight(),h=n.height/n.width,v=m*h;if(v<=e*1.22){const i=Math.min(v,e),s=i/h,b=(m-s)/2;o.addImage(p,"JPEG",b,0,s,i)}else{const i=n.width/m,s=e*i,b=Math.ceil(n.height/s);for(let f=0;f<b;f++){f>0&&o.addPage();const c=document.createElement("canvas");c.width=n.width,c.height=Math.min(s,n.height-f*s);const w=c.getContext("2d");w.fillStyle="#ffffff",w.fillRect(0,0,c.width,c.height),w.drawImage(n,0,-f*s);const _=c.toDataURL("image/jpeg",.95),k=c.height/i;o.addImage(_,"JPEG",0,0,m,k)}}o.save(a.filename.endsWith(".pdf")?a.filename:`${a.filename}.pdf`)}finally{d.remove()}},[]),u=E.useCallback(async t=>{if(!t)return;const a=await P(t),d=a.contentWindow;d.focus(),d.print(),setTimeout(()=>a.remove(),1e3)},[]);return{exportNodeToPdf:g,printNode:u}}export{W as u};
